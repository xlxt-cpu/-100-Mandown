#pragma once
void MysqlTest(int argc, char *argv[]);