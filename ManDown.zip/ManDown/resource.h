//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� ManDown.rc ʹ��
//
#define IDB_PNG1                        110
#define IDB_PNG2                        111
#define IDB_PNG3                        112
#define IDB_PNG4                        113
#define IDB_PNG5                        114
#define IDB_PNG6                        115
#define IDB_PNG7                        116
#define IDB_PNG8                        117
#define IDB_PNG9                        118
#define IDB_PNG10                       119
#define IDB_PNG11                       120
#define IDB_PNG12                       121
#define IDB_PNG13                       122
#define IDB_PNG14                       123
#define IDB_BITMAP1                     124
#define IDB_BITMAP2                     125
#define IDB_BITMAP3                     126
#define IDB_BITMAP4                     127
#define IDB_BITMAP5                     128
#define IDB_BITMAP6                     129
#define IDB_BITMAP7                     130
#define IDB_BITMAP8                     131
#define IDR_MP31                        139
#define IDR_MP32                        140
#define IDR_MP33                        141
#define IDR_MP34                        142
#define IDR_MP35                        143
#define IDR_MP36                        144
#define IDR_MP37                        145

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
